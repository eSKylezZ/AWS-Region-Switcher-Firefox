var currentURL = window.location.href;
currentURL = encodeURIComponent(currentURL);

switch(currentURL) {
    case "https%3A%2F%2Fus-east-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dus-east-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fus-east-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dus-east-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fus-east-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dus-east-2":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fus-east-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dus-east-2%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fus-west-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dus-west-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fus-west-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dus-west-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fus-west-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dus-west-2":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fus-west-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dus-west-2%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Faf-south-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Daf-south-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Faf-south-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Daf-south-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fca-central-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dca-central-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fca-central-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dca-central-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Feu-west-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Deu-west-2":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Feu-west-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Deu-west-2%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Feu-central-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Deu-central-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Feu-central-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Deu-central-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fap-southeast-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-southeast-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fap-southeast-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-southeast-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fap-southeast-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-southeast-2":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fap-southeast-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-southeast-2%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fap-south-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-south-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fap-south-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-south-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fap-northeast-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-northeast-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fap-northeast-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-northeast-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fap-northeast-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-northeast-2":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fap-northeast-2.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-northeast-2%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fsa-east-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dsa-east-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fsa-east-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dsa-east-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fap-east-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-east-1":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fap-east-1.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dap-east-1%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
        
    case "https%3A%2F%2Fnortheast-3.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dnortheast-3":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    case "https%3A%2F%2Fnortheast-3.console.aws.amazon.com%2Fconsole%2Fhome%3Fregion%3Dnortheast-3%23":
        window.location.href = "https://eu-west-1.console.aws.amazon.com/";
        break;
    default:
        //Blank not required
    }